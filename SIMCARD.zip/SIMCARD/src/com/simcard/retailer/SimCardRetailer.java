package com.simcard.retailer;
import com.simcard.InterfaceImplements.Transaction;
import com.simcard.Main.Main;
import com.simcard.customer.CustomerInfo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
public class SimCardRetailer {
	 private final static  List<Transaction> transactions = new LinkedList<>();

	    public static void addTransaction() {
	        CustomerInfo customer = new CustomerInfo();
	        transactions.add(new Transaction(customer));
	    }

	    public static void getTransactions() {
	        if (transactions.isEmpty()) {
	            System.out.println("No registered customers!");
	            return;
	        }
	        System.out.println("Choose 1 to get Customer details by SimCard");
	        System.out.println("Choose 2 to get Customer details by date");
	        System.out.println("Choose 3 to get all Customer details");
	        int ch;
	        try {
	            ch = Integer.parseInt(Main.scanner.nextLine());
	        } catch (NumberFormatException e) {
	            System.out.println("Not a valid choice!");
	            return;
	        }
	        if (ch == 1) {
	            System.out.println("Enter SimCard type(Airtel/Vodaphone/Jio) : ");
	           getTransactionsBySimCardType(Main.scanner.nextLine());
	        } else if (ch == 2) {
	            System.out.println("Enter Date(dd/MM/yyyy) : ");
	           DateTimeFormatter formatter = null;
			getTransactionsByDate(LocalDate.parse(Main.scanner.nextLine(), formatter));
	        } else if (ch == 3) {
	            for (Transaction transaction : transactions) {
	                System.out.println(transaction);
	            }
	        }
	    }

	    public static void getTransactionsBySimCardType(String simCardType) {
	        boolean isEmpty = true;
	        for (Transaction transaction : transactions) {
	            if (transaction.getCustomer().getSimCardType().toString().equalsIgnoreCase(simCardType)) {
	                System.out.println(transaction);
	                isEmpty = false;
	            }
	        }
	        if (isEmpty) {
	            System.out.println("No registered customers for the SIMCard type " + simCardType);
	        }
	    }

	    public static void getTransactionsByDate(LocalDate date) {
	        boolean isEmpty = true;
	        for (Transaction transaction : transactions) {
	            if (transaction.getDateOfRegistration().equals(date)) {
	                System.out.println(transaction);
	                isEmpty = false;
	            }
	        }
	        if (isEmpty) {
	            System.out.println("No registered customers for the given date " + date);
	        }
	    }

	    public static List<Transaction> getTransactionsList() {
	        return transactions;
	    }
	}

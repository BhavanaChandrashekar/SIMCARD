package com.simcard.Main;


import java.util.Scanner;

import com.simcard.Interface.SimCard;
import com.simcard.InterfaceImplements.Airtel;
import com.simcard.InterfaceImplements.Jio;
import com.simcard.InterfaceImplements.Transaction;
import com.simcard.InterfaceImplements.Vodaphone;
import com.simcard.customer.CustomerInfo;
public class Main  {
	public static final Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
	while(true) {
	System.out.println("**** WELCOME TO SIMCARD POC ****");
	System.out.println("choose \n 1.Retailer \n 2.Custumor \n 3.Exit ");
	System.out.println("Enter your choice (1 or 2 or 3  ):");
	int n;
    try {
        n = Integer.parseInt(scanner.nextLine());
    } catch (NumberFormatException e) {
        System.out.println("Not a valid choice!");
        continue;
    }
    if (n == 3) {
        scanner.close();
        break;
    } else {
        System.out.println();
      
		switch (n) {
            case 1:
                System.out.println("Welcome To Simcard Retailer");
                System.out.println("********************");
                while (true) {
                    System.out.println("Choose 1 to add Customer");
                    System.out.println("Choose 2 to check Registered Customers");
                    System.out.println("Choose 3 to go back");
                    int ch;
                    try {
                        ch = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Not a valid choice!");
                        continue;
                    }
                    if (ch == 1) {
                        com.simcard.retailer.SimCardRetailer.addTransaction();
                    } else if (ch == 2) {
                        com.simcard.retailer.SimCardRetailer.getTransactions();
                    } else
                        break;
                }
                break;
            case 2:
                if (com.simcard.retailer.SimCardRetailer.getTransactionsList().isEmpty()) {
                    System.out.println("No registered customers to retailer!");
                } else {
                    System.out.println("");
                    for (Transaction t : com.simcard.retailer.SimCardRetailer.getTransactionsList()) {
                        System.out.println(t.getCustomer().getSimCardType().getPhoneNumber() + " ---> " + t.getCustomer().getSimCardType());
                    }
                    System.out.println("Enter your phone number from above : ");
                    String phoneNumber = scanner.nextLine();
                    CustomerInfo customer = null;
                    for (Transaction t : com.simcard.retailer.SimCardRetailer.getTransactionsList()) {
                        if (t.getCustomer().getSimCardType().getPhoneNumber().equals(phoneNumber)) {
                            customer = t.getCustomer();
                            break;
                        }
                    }

                    if (customer == null) {
                        System.out.println("Not a registered customer!");
                        break;
                    }

                    while (true) {
                        System.out.println("Welcome To Customer");
                        System.out.println("********************");
                        System.out.println("Choose 1 to know SIM status");
                        System.out.println("Choose 2 to activate SIM");
                        System.out.println("Choose 3 to know SIM expiry Date");
                        System.out.println("Choose 4 to know Phone Number");
                        System.out.println("Choose 5 to send SMS");
                        System.out.println("Choose 6 to make Call");
                        System.out.println("Choose 7 to check balance");
                        System.out.println("Choose 8 to see available offers");
                        System.out.println("Choose 9 to recharge");
                        System.out.println("Choose 10 to port to other network");
                        System.out.println("Choose 11 to go back");
                        int ch;
                        try {
                            ch = Integer.parseInt(scanner.nextLine());
                        } catch (NumberFormatException e) {
                            System.out.println("Not a valid choice!");
                            continue;
                        }
                        if (ch == 11) {
                            break;
                        }
                        SimCard sim = customer.getSimCardType();
                        switch (ch) {
                            case 1:
                                if (sim.getSIMStatus()) {
                                    System.out.println("SIM is active");
                                } else {
                                    System.out.println("SIM is inactive!");
                                }
                                break;
                            case 2:
                                sim.activateSIM();
                                break;
                            case 3:
                                sim.getSIMExpiry();
                                break;
                            case 4:
                                System.out.println(sim.getPhoneNumber());
                                break;
                            case 5:
                                sim.sendSMS();
                                break;
                            case 6:
                                sim.call();
                                break;
                            case 7:
                                System.out.println(sim.checkBalance());
                                break;
                            case 8:
                                sim.offerAvailable();
                                break;
                            case 9:
                                sim.recharge();
                                break;
                            case 10:
                                System.out.println("Enter network(Airtel/Vodafone/Jio)" +
                                        " that you would like port to : ");
                                String port = scanner.nextLine();
                                if (port.equalsIgnoreCase("Airtel"))
                                    customer.portNetwork(new Airtel());
                                else if (port.equalsIgnoreCase("Vodaphone"))
                                    customer.portNetwork(new Vodaphone());
                                else
                                    customer.portNetwork(new Jio());
                                break;
                        }
                    }
                }
                
        }
    }
}
}
}


		



package com.simcard.InterfaceImplements;
import java.time.LocalDate;
import java.util.*;

import com.simcard.Interface.SimCard;
import com.simcard.Main.Main;

public class Jio implements SimCard {
	private float balance;
    private final int[] rechargePlan;
    private int SMSCount;
    private boolean statusSIM;
    private LocalDate activationDate;
    private String phoneNumber;
    private final String simCardNo;

    public Jio() {
        this.balance = SimCard.balance;

        this.phoneNumber = SimCard.phoneNo.replace("xxxxxxxxx",
                String.format("%d", new Random().nextInt(0000000000)));

        this.simCardNo = SimCard.simCardNo.replace("xxxxxxxxxxxxxxxx",
                String.format("%d", new Random().nextLong()));

        this.rechargePlan = new int[]{
                100, 149, 199, 249, 349, 399,
                401, 444, 555, 599, 999,
                2121, 2399, 2599, 4999
        };
    }

    public String getSimCardNo() {
        return this.simCardNo;
    }

    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public boolean getSIMStatus() {
        return statusSIM;
    }

    @Override
    public void activateSIM() {
        if (!this.getSIMStatus()) {
            this.statusSIM = true;
            this.activationDate = LocalDate.now();
            System.out.println("SIM is activated!");

        } else {
            System.out.println("SIM already activated!");
        }
    }

    @Override
    public void getSIMExpiry() {
        if (!this.statusSIM) {
            System.out.println("SIM not activated!");
            return;
        }
        System.out.println("SIM deactivates from the network after 30 days non-usage criteria i.e " + this.activationDate.plusDays(90));
    }

    @Override
    public float checkBalance() {
        return this.balance;
    }

    @Override
    public void recharge() {
        if (!this.statusSIM) {
            System.out.println("SIM not activated!");
            return;
        }

        offerAvailable();
        System.out.println("Please choose recharge amount from above : ");
        int amount;
        try {
            amount = Integer.parseInt(Main.scanner.nextLine());
        } catch (InputMismatchException | NumberFormatException e) {
            System.out.println("Please enter valid amount to recharge!");
            return;
        }
        boolean validAmount = false;
        for (int i : rechargePlan) {
            if (amount == i) {
                validAmount = true;
                this.balance += amount;
                this.SMSCount = 100;
                System.out.println("Amount Rs." + amount + " recharged successfully! " +
                        "Available balance is Rs. " + checkBalance());
                break;
            }
        }
        if (!validAmount) {
            System.out.println("Recharge of amount Rs." + amount + " failed! Enter valid amount.");
        }
    }

    @Override
    public void offerAvailable() {
        if (!this.statusSIM) {
            System.out.println("SIM not activated!");
            return;
        }

        System.out.println("Available Unlimited plan offers : ");
        for (int i : rechargePlan) {
            System.out.println("Recharge Plan : Rs." + i);
        }
    }

    @Override
    public void sendSMS() {
        if (!this.statusSIM) {
            System.out.println("SIM not activated!");
            return;
        }

        String recipientNo;
        String message;

        if (this.checkBalance() <= 0) {
            System.out.println("SMS Sending failed! Make sure you have enough balance.");
        } else {
            System.out.println("Please enter recipient number : ");
            try {
                recipientNo = Main.scanner.next("[0-9]{10}");
            } catch (NoSuchElementException e) {
                System.out.println("Not a valid recipient number!");
                return;
            }

            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            if (hour >= 23) {
                this.SMSCount = 100;
            }
            Main.scanner.nextLine();
            System.out.println("Please enter message to send : ");
            message = Main.scanner.nextLine();

            if (message.length() > 110) {
                System.out.println("Max Chars allowed is 110");
            } else {
                this.SMSCount--;
                System.out.println("Message \"" + message + "\" sent to " + recipientNo + " successfully! " +
                        "Available SMS balance is " + this.SMSCount);
            }
        }
    }

    @Override
    public void call() {
        if (!this.statusSIM) {
            System.out.println("SIM not activated!");
            return;
        }

        String recipientNo;

        System.out.println("Please enter recipient number : ");
        try {
            recipientNo = Main.scanner.next("[0-9]{10}");
        } catch (NoSuchElementException e) {
            System.out.println("Not a valid recipient number!");
            Main.scanner.nextLine();
            return;
        }
        Main.scanner.nextLine();

        if (this.checkBalance() <= 0) {
            System.out.println("Call failed! Please check your balance.");
            return;
        } else {
            System.out.println("Call to " + recipientNo + " made successfully!");
        }

        long start = System.currentTimeMillis();
        System.out.println("Press any key to quit call");
        Main.scanner.nextLine();
        long end = System.currentTimeMillis();
        float seconds = (end - start) / 1000F;
        System.out.println("Call ended successfully. " + seconds + " seconds elapsed");
    }

    @Override
    public String toString() {
        return "Jio";
    }
}



package com.simcard.InterfaceImplements;

import java.time.LocalDate;

import com.simcard.customer.CustomerInfo;

public class Transaction {
	    private CustomerInfo customer;
	    private LocalDate dateOfRegistration;

	    public Transaction(CustomerInfo customer) {
	        this.customer = customer;
	        this.dateOfRegistration = LocalDate.now();
	    }

	    public CustomerInfo getCustomer() {
	        return customer;
	    }

	    public void setCustomer(CustomerInfo customer) {
	        this.customer = customer;
	    }

	    public LocalDate getDateOfRegistration() {
	        return dateOfRegistration;
	    }

	    public void setDateOfRegistration(LocalDate dateOfRegistration) {
	        this.dateOfRegistration = dateOfRegistration;
	    }

	    @Override
	    public String toString() {
	        return "Transaction details" + '\n' +
	                "-------------------" + '\n' +
	                customer + '\n' +
	                "Date Of Registration = " + dateOfRegistration + '\n';
	    }
	}



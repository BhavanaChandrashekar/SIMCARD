package com.simcard.InterfaceImplements;

import java.time.LocalDate;
import java.util.*;

import com.simcard.Interface.SimCard;
import com.simcard.Main.Main;

public class Vodaphone implements SimCard {

    private float balance;
    private final int[] rechargePlan;
    private final int rechargePlanISD;
    private final float callCharge;
    private final float smsCharge;
    private final float smsChargeISD;
    private final float callChargeISD;
    private boolean statusSIM;
    private String phoneNumber;
    private final String simCardNo;
    private LocalDate activationDate;

    public Vodaphone() {
        this.balance = SimCard.balance;

        this.phoneNumber = SimCard.phoneNo.replace("xxxxxxxxx",
                String.format("%d", new Random().nextInt(0000000000)));

        this.simCardNo = SimCard.simCardNo.replace("xxxxxxxxxxxxxxxx",
                String.format("d", new Random().nextLong()));

        this.rechargePlan = new int[]{
                10, 20, 30, 39, 49, 50,
                79, 99, 150, 999, 1000,
                5000
        };
        this.rechargePlanISD = 27;
        this.callCharge = 2; 
        this.callChargeISD = 25;
        this.smsCharge = 1;
        this.smsChargeISD = 3; //3 rs/sms
    }

    public String getSimCardNo() {
        return this.simCardNo;
    }

    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public boolean getSIMStatus() {
        return statusSIM;
    }

    @Override
    public void activateSIM() {
        if (!this.getSIMStatus()) {
            this.statusSIM = true;
            this.activationDate = LocalDate.now();
            System.out.println("Message \"" + this.getSimCardNo() + "\" sent to " + 59059 + " successfully! SIM activated!");
        } else {
            System.out.println("SIM already activated!");
        }
    }

    @Override
    public void getSIMExpiry() {
        if (!this.statusSIM) {
            System.out.println("SIM not activated!");
            return;
        }
        System.out.println("SIM deactivates from the network after 30 days non-usage criteria i.e " + this.activationDate.plusDays(90));
    }

    @Override
    public float checkBalance() {
        return this.balance;
    }

    @Override
    public void recharge() {
        offerAvailable();
        System.out.println("Please choose recharge amount from above : ");
        int amount;
        try {
            amount = Integer.parseInt(Main.scanner.nextLine());
        } catch (InputMismatchException | NumberFormatException e) {
            System.out.println("Please enter valid amount to recharge!");
            return;
        }
        boolean validAmount = false;
        for (int i : rechargePlan) {
            if (amount == i) {
                validAmount = true;
                this.balance += amount;
                System.out.println("Amount Rs." + amount + " recharged successfully! " +
                        "Available balance is Rs. " + checkBalance());
                break;
            }
        }
        if (amount == this.rechargePlanISD) {
            System.out.println("ISD pack of amount Rs." + amount + " recharged successfully! " +
                    "Available balance is Rs. " + checkBalance());
        }
        if (!validAmount) {
            System.out.println("Recharge of amount Rs." + amount + " failed! Enter valid amount.");
        }
    }

    @Override
    public void offerAvailable() {
        System.out.println("Available offers : ");
        for (int i : rechargePlan) {
            System.out.println("Recharge Plan : Rs." + i);
        }
        System.out.println("ISD Recharge Plan : Rs." + this.rechargePlanISD);
    }

    @Override
    public void sendSMS() {
        String recipientNo;
        String message;
        boolean ISDSms = false;

        if (this.checkBalance() <= 0) {
            System.out.println("SMS Sending failed! Make sure you have enough balance.");
        } else {
            System.out.println("Please enter recipient number with country code : ");
            try {
                recipientNo = Main.scanner.next("[0-9]{7,18}");
            } catch (NoSuchElementException e) {
                System.out.println("Not a valid recipient number!");
                return;
            }

            if (!recipientNo.startsWith("91")) {
                ISDSms = true;
                System.out.println("International SMS!");
            }

            Main.scanner.nextLine();
            System.out.println("Please enter message to send : ");
            message = Main.scanner.nextLine();

            if (message.length() > 99) {
                System.out.println("Max Chars allowed is 99");
            } else {
                this.balance = this.balance - (ISDSms ? smsChargeISD : smsCharge);
                System.out.println("Message \"" + message + "\" sent to " + recipientNo + " successfully! " +
                        "Available balance is Rs. " + checkBalance());
            }
        }
    }

    @Override
    public void call() {
        String recipientNo;
        boolean ISDCall = false;

        System.out.println("Please enter recipient number with country code : ");
        try {
            recipientNo = Main.scanner.next("[0-9]{7,18}");
        } catch (NoSuchElementException e) {
            System.out.println("Not a valid recipient number!");
            Main.scanner.nextLine();
            return;
        }
        Main.scanner.nextLine();

        if (!recipientNo.startsWith("91")) {
            ISDCall = true;
            System.out.println("International Call!");
        }

        if (this.checkBalance() <= 0) {
            System.out.println("Call failed! Please check your balance.");
            return;
        } else {
            System.out.println("Call to " + recipientNo + " made successfully!");
        }

        long start = System.currentTimeMillis();
        System.out.println("Press any key to quit call");
        Main.scanner.nextLine();
        long end = System.currentTimeMillis();
        float seconds = (end - start) / 1000F;
        float charge = (seconds * (ISDCall ? callChargeISD : callCharge)) / 100;
        this.balance = this.balance - charge;
        System.out.println("Call ended successfully. " + seconds + " seconds elapsed. Charged Rs. " + charge +
                ". Available balance is Rs. " + checkBalance());
    }

    @Override
    public String toString() {
        return "Vodaphone";
    }
}

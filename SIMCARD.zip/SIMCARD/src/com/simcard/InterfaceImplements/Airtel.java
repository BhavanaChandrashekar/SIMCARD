package com.simcard.InterfaceImplements;
import java.time.LocalDate;
import java.util.*;

import com.simcard.Interface.SimCard;
import com.simcard.Main.Main;
public class Airtel implements SimCard {
	
		// TODO Auto-generated method stub
		private float balance;
	    private final int[] rechargePlan;
	    private final float callCharge;
	    private final float smsCharge;
	    private final String simCardNo;
	    private String phoneNumber;
	    private boolean statusSIM;
	    private LocalDate activationDate;

	    public Airtel() {
	        this.balance = SimCard.balance;

	        this.phoneNumber = SimCard.phoneNo.replace("xxxxxxxxx",
	                String.format("%d", new Random().nextInt(0000000000)));

	        this.simCardNo = SimCard.simCardNo.replace("xxxxxxxxxxxxxxxx",
	                String.format("%d", new Random().nextLong()));

	        this.rechargePlan = new int[]{
	                10, 20, 45, 49, 79,
	                99, 499, 999, 5000
	        };
	        this.callCharge = 2; 
	        this.smsCharge = 1; 
	    }

	    public String getSimCardNo() {
	        return this.simCardNo;
	    }

	    @Override
	    public void setPhoneNumber(String phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }

	    @Override
	    public String getPhoneNumber() {
	        return phoneNumber;
	    }

	    @Override
	    public boolean getSIMStatus() {
	        return statusSIM;
	    }

	    @Override
	    public void activateSIM() {
	        if (!this.getSIMStatus()) {
	            this.statusSIM = true;
	            this.activationDate = LocalDate.now();
	            System.out.println("Message \"" + this.getSimCardNo() + "\" sent to " + 121 + " successfully! SIM activated!");
	        } else {
	            System.out.println("SIM already activated!");
	        }
	    }

	    @Override
	    public void getSIMExpiry() {
	        if (!this.statusSIM) {
	            System.out.println("SIM not activated!");
	            return;
	        }
	        System.out.println("SIM deactivates from the network after 60 days non-usage criteria i.e " + this.activationDate.plusDays(60));
	    }

	    @Override
	    public float checkBalance() {
	        return this.balance;
	    }

	    @Override
	    public void recharge() {
	        if (!this.statusSIM) {
	            System.out.println("SIM not activated!");
	            return;
	        }
	        offerAvailable();
	        System.out.println("Please choose recharge amount from above : ");
	        int amount;
	        try {
	            amount = Integer.parseInt(Main.scanner.nextLine());
	        } catch (InputMismatchException | NumberFormatException e) {
	            System.out.println("Please enter valid amount to recharge!");
	            return;
	        }
	        boolean validAmount = false;
	        for (int i : rechargePlan) {
	            if (amount == i) {
	                validAmount = true;
	                this.balance += amount;
	                System.out.println("Amount Rs." + amount + " recharged successfully! " +
	                        "Available balance is Rs. " + checkBalance());
	                break;
	            }
	        }
	        if (!validAmount) {
	            System.out.println("Recharge of amount Rs." + amount + " failed! Enter valid amount.");
	        }
	    }

	    @Override
	    public void offerAvailable() {
	        if (!this.statusSIM) {
	            System.out.println("SIM not activated!");
	            return;
	        }
	        System.out.println("Available offers : ");
	        for (int i : rechargePlan) {
	            System.out.println("Recharge Plan : Rs." + i);
	        }
	    }

	    @Override
	    public void sendSMS() {
	        if (!this.statusSIM) {
	            System.out.println("SIM not activated!");
	            return;
	        }
	        String recipientNo;
	        String message;
	        if (this.checkBalance() <= 0) {
	            System.out.println("SMS Sending failed! Make sure you have enough balance.");
	        } else {
	            System.out.println("Please enter recipient number : ");
	            try {
	                recipientNo = Main.scanner.next("[0-9]{10}");
	            } catch (NoSuchElementException e) {
	                System.out.println("Not a valid recipient number!");
	                return;
	            }
	            Main.scanner.nextLine();
	            System.out.println("Please enter message to send : ");
	            message = Main.scanner.nextLine();
	            if (message.length() > 160) {
	                System.out.println("Max Chars allowed is 160!");
	            } else {
	                this.balance = this.balance - smsCharge;
	                System.out.println("Message \"" + message + "\" sent to " + recipientNo + " successfully! " +
	                        "Available balance is Rs. " + checkBalance());
	            }
	        }
	    }

	    public void call() {
	        if (!this.statusSIM) {
	            System.out.println("SIM not activated!");
	            return;
	        }
	        String recipientNo;
	        System.out.println("Please enter recipient number : ");
	        try {
	            recipientNo = Main.scanner.next("[0-9]{10}");
	        } catch (NoSuchElementException e) {
	            System.out.println("Not a valid recipient number!");
	            Main.scanner.nextLine();
	            return;
	        }
	        Main.scanner.nextLine();
	        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
	        if (hour >= 23 || hour <= 6) { //Night Call facility
	            System.out.println("Call to " + recipientNo + " made successfully!");
	        } else {
	            if (this.checkBalance() <= 0) {
	                System.out.println("Call failed! Please check your balance.");
	                return;
	            } else {
	                System.out.println("Call to " + recipientNo + " made successfully!");
	            }
	        }
	        long start = System.currentTimeMillis();
	        System.out.println("Press any key to quit call");
	        Main.scanner.nextLine();
	        long end = System.currentTimeMillis();
	        float seconds = (end - start) / 1000F;
	        float charge = (seconds * callCharge) / 100;
	        this.balance = this.balance - charge;
	        System.out.println("Call ended successfully. " + seconds + " seconds elapsed. Charged Rs. " + charge +
	                ". Available balance is Rs. " + checkBalance());
	    }

	    @Override
	    public String toString() {
	        return "Airtel";
	    }
	}




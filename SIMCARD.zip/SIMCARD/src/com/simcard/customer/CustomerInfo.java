package com.simcard.customer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.simcard.Interface.SimCard;
import com.simcard.InterfaceImplements.Airtel;
import com.simcard.InterfaceImplements.Jio;
import com.simcard.InterfaceImplements.Vodaphone;
import com.simcard.Main.Main;
public class CustomerInfo {
  private String firstName;
    private String lastName;
    private String gender;
    private Address address;
    private LocalDate dateOfBirth;
    private SimCard simCardType;

    public CustomerInfo(String firstName, String lastName, String gender,
                        Address address, LocalDate dateOfBirth, SimCard simCardType) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.simCardType = simCardType;
    }
    public void diplay() {
    	System.out.println("Welcome To Custmer Page");
    }

    public CustomerInfo() {
        System.out.println("Enter Customer details");
        System.out.println("**************************");

        System.out.println("Enter First Name : ");
        setFirstName(Main.scanner.nextLine().trim());

        System.out.println("Enter Last Name : ");
        setLastName(Main.scanner.nextLine().trim());

        System.out.println("Enter Gender(Male/Female/Other) : ");
        setGender(Main.scanner.nextLine().trim());

        System.out.println("Enter Date of Birth(dd/MM/yyyy) : ");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            setDateOfBirth(LocalDate.parse(Main.scanner.nextLine().trim(), formatter));
        } catch (DateTimeParseException e) {
            System.out.println(" Error!");
        }

        this.address = new Address();

        System.out.println("Enter SimCard type(Airtel/Vodaphone/Jio) : ");
        String simCard = Main.scanner.nextLine().trim();
        if (simCard.equalsIgnoreCase("Airtel")) {
            setSimCardType(new Airtel());
        } else if (simCard.equalsIgnoreCase("Vodaphone")) {
            setSimCardType(new Vodaphone());
        } else if (simCard.equalsIgnoreCase("Jio")) {
            setSimCardType(new Jio());
        } else {
            System.out.println("Not a valid input! Defaulting SimCard type to Airtel!");
            setSimCardType(new Airtel());
        }
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female") ||
                gender.equalsIgnoreCase("Other")) {
            this.gender = gender;
        } else {
            System.out.println("Not a valid gender");
            this.gender = null;
        }
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public SimCard getSimCardType() {
        return simCardType;
    }

    public void setSimCardType(SimCard simCardType) {
        this.simCardType = simCardType;
    }

    public void portNetwork(SimCard newSimCardType) {
        String oldPhoneNo = this.simCardType.getPhoneNumber();
        SimCard oldSimCard = this.simCardType;
        if (oldSimCard.toString().equals(newSimCardType.toString())) {
            System.out.println("Cannot port to the same network!  ");
            return;
        }
        this.simCardType = newSimCardType;
        this.simCardType.setPhoneNumber(oldPhoneNo);
        System.out.println("Ported network from " + oldSimCard + " to " + this.simCardType + " successfully!");
    }

    @Override
    public String toString() {
        return "First Name = " + firstName + '\n' +
                "Last Name = " + lastName + '\n' +
                "Gender = " + gender + '\n' +
                address + '\n' +
                "Date Of Birth = " + dateOfBirth + '\n' +
                "SimCard = " + simCardType;
    }
}

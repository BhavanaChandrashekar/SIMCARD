package com.simcard.Interface;

public interface SimCard {
    float balance = 100f;
    String simCardNo = "xxxxxxxxxxxxxxxx";
    String phoneNo = "xxxxxxxxx";

    float checkBalance();

    void recharge();

    void offerAvailable();

    void sendSMS();

    void call();

    void getSIMExpiry();

    void activateSIM();

    String getPhoneNumber();

    void setPhoneNumber(String phoneNumber);

    boolean getSIMStatus();
}
